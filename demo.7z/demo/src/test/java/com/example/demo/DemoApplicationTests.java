package com.example.demo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.ui.Model;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@SpringBootTest
class DemoApplicationTests {

    private DemoApplication demoApplication;
    private Model modelMock;

    @BeforeEach
    void setUp() {
        demoApplication = new DemoApplication();
        modelMock = mock(Model.class);
    }

    @Test
    void multiplyNumber_ValidNumber_ReturnsResult() {
        String numberStr = "10";
        String expectedAttribute = "Результат: 70";

        String viewName = demoApplication.multiplyNumber(numberStr, modelMock);

        assertEquals("multiply", viewName);
        verify(modelMock).addAttribute("result", expectedAttribute);
    }

    @Test
    void multiplyNumber_InvalidNumber_RedirectsToErrorPage() {
        String numberStr = "abc";

        String viewName = demoApplication.multiplyNumber(numberStr, modelMock);

        assertEquals("redirect:/error-500", viewName);
        verify(modelMock, never()).addAttribute(eq("result"), any());
    }

    @Test
    void handleIllegalArgumentException_ReturnsMultiplyViewWithError() {
        IllegalArgumentException exceptionMock = mock(IllegalArgumentException.class);

        String viewName = demoApplication.handleIllegalArgumentException(exceptionMock, modelMock);

        assertEquals("multiply", viewName);
        verify(modelMock).addAttribute(eq("error"), anyString());
    }

    @Test
    void handleException_ReturnsMultiplyViewWithError() {
        Exception exceptionMock = mock(Exception.class);

        String viewName = demoApplication.handleException(exceptionMock, modelMock);

        assertEquals("multiply", viewName);
        verify(modelMock).addAttribute(eq("error"), anyString());
    }
}